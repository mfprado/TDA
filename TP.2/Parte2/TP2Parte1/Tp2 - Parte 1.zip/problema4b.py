import sys
from main import main
import distancias
import ej_1

def problema4b ():
		main(sys.argv, distancias.distancia_euclidea, ej_1.ejercicio_4_b)

problema4b()