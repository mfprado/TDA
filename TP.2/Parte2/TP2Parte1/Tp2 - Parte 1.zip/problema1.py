import sys
from main import main
import distancias
import ej_1

def problema1a ():
		main(sys.argv, distancias.sin_distancia, ej_1.ejercicio_1)

problema1a()
