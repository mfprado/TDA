from heapq import heappush, heappop
from collections import deque

class Grafo (object):
	
	def __init__(self):
		self.vertices ={}
	
	def agregar_arista(self,cord_x,cord_y,peso = 1):
		if not cord_x in self.vertices:
			self.vertices[cord_x] = []
		if not cord_y in self.vertices:
			self.vertices[cord_y] = []
		self.vertices[cord_x].append((cord_y,peso))
	
	
	def camino_minimo(self,origen,destino,con_camino = False):
		if destino!= None:
			if not origen in self.vertices or not destino in self.vertices:
				raise KeyError()
		
		vecinos = []
		vuelta = {}
		costos = {}
		heappush(vecinos, (0, origen))
		vuelta[origen] = None
		costos[origen] = 0

		while vecinos:
			actual = heappop(vecinos)[1]
			if actual == destino:
				break
			for v,peso in self.vertices[actual]:
				
				#if v in self.vertices:
				nuevo_costo = costos[actual] + peso

				if not v in costos or nuevo_costo < costos[v]:
					costos[v] = nuevo_costo
					heappush(vecinos,(nuevo_costo, v))
					vuelta[v] = actual
		if not destino in costos:
			return None, -1
		if con_camino == True:
			return self.reconstruir_camino(vuelta, origen, destino),costos[destino] 
		else:
			return costos[destino]
	
	
	def obtener_camino(self,origen,destino, con_camino = False):
		if origen == destino:
			if con_camino == True:
				return [origen]
			else:
				return 1
		padre, orden = self.bfs(origen)
		camino = self.reconstruir_camino(padre,origen,destino)
		if con_camino == True:
			return camino
		else:
			if camino != None:
				return len(camino)
			else:
				return -1
	
	
	def bfs(self, inicio=None):
		if inicio == None:
			inicio = self.vertices.keys()[0]
		cola = deque([inicio])
		padre = {inicio: None}
		orden = {inicio: 0}
		visitados = []

		while len(cola) > 0:
			v = cola.popleft()
			visitados.append(v)

			for vertice,peso in self.vertices[v]:
				if not vertice in visitados:
					cola.append(vertice)
					padre[vertice] = v
					orden[vertice] = orden[v] + 1
					visitados.append(vertice)

		return padre,orden
	
	def reconstruir_camino(self, vuelta, origen, destino):
		if not destino in vuelta:
			return None
		camino = []
		while destino != origen:
			camino.append(destino)
			destino = vuelta[destino]
		camino.append(destino)
		camino.reverse()
		return camino
	
	def imprimir_grafo(self):
		print self.vertices
