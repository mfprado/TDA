import sys
from main import main
import distancias
import ej_1

def problema4a ():
		main(sys.argv, distancias.sin_distancia, ej_1.ejercicio_4_a)

problema4a()